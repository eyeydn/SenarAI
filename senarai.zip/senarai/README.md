# SenarAI — online audio-to-chords prototype

A runnable prototype for Android browser testing. Upload a short audio file; the server estimates chord segments with chroma templates, transcribes lyrics with `faster-whisper` if its model can be loaded, and optionally creates candidate note/fret events using Spotify Basic Pitch.

## Important accuracy limits

- This is a research prototype, not a production-grade guitar transcription engine.
- Chords are inferred from the whole mix using chroma; piano/bass/vocals can affect the answer.
- Basic Pitch is designed for note transcription and works best with one instrument at a time. The fretboard mapping chooses a playable position, but it cannot infer the exact original guitar fingering.
- Singing is harder to transcribe than speech. Review lyrics and timestamps manually.
- Capo recommendations and automatic stem separation are not implemented in this first version; the UI says so rather than inventing a result.
- Uploads are processed in a temporary directory and deleted after each request. Do not upload audio you do not have permission to process. Hosting providers may retain request logs; check their policies.

## Run locally (PC or Linux server)

Python 3.11 is recommended. FFmpeg and libsndfile are required for audio decoding.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Open `http://127.0.0.1:8000`. To test from Android on the same Wi-Fi, open `http://YOUR_COMPUTER_LAN_IP:8000` (allow port 8000 through the computer firewall). Check `http://YOUR_COMPUTER_LAN_IP:8000/health`.

The first lyrics request downloads the Whisper model, so the first analysis may take a while. Set `WHISPER_MODEL=base` for lower resource use or `small` for a better balance; `medium` can be more accurate but requires more compute and storage. On a CPU host, the first run can be slow.

## Docker

```bash
docker build -t senarai .
docker run --rm -p 8000:8000 senarai
```

Then open `http://localhost:8000` or the host's LAN IP from Android.

## Deploy online

Deploy the Dockerfile to a container host that supports persistent outbound internet for model downloads and enough RAM/CPU. Configure port `8000`. For a real public deployment, add authentication, rate limiting, request-size controls at the proxy, HTTPS, job queues, and cost limits before sharing it. CPU-only free hosting may sleep, run out of memory, or time out on audio/model inference.

## Optional Basic Pitch tab candidates

Basic Pitch has platform/runtime constraints. Test it separately on the server before enabling it in production:

```bash
pip install basic-pitch
```

The endpoint catches import/model errors and reports tab candidates unavailable rather than crashing the whole analysis. For better tab quality, the next major step is source separation (e.g. Demucs/MDX) and then running note transcription on the guitar stem, not the complete mix.

## API

- `GET /health` — health check
- `POST /analyze` — multipart upload field `file`; accepts MP3, WAV, M4A, OGG, FLAC, WEBM up to `MAX_UPLOAD_MB`

## Planned next improvements

1. Add source separation worker (Demucs/MDX) on a GPU-backed server.
2. Run chord estimation on separated accompaniment/guitar and compare multiple candidates.
3. Improve note-to-tab assignment using continuity, tuning, string bends and hand-position costs.
4. Align chord timestamps to lyric words and render chords above syllables.
5. Generate capo alternatives by evaluating chord-shape difficulty after transposition; never assume capo is necessary.
6. Add user correction UI so confirmed chord changes improve the next export.
