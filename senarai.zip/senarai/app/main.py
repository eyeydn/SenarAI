from __future__ import annotations
import os, tempfile, shutil, subprocess, math
from pathlib import Path
from typing import Any
import numpy as np
import librosa
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles

ROOT = Path(__file__).resolve().parent
MAX_BYTES = int(os.getenv("MAX_UPLOAD_MB", "30")) * 1024 * 1024
app = FastAPI(title="SenarAI", version="0.1.0", description="Song audio to chord, lyric and guitar-tab prototype")
app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")

NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
CHORD_TEMPLATES = {}
for root in range(12):
    for suffix, intervals in [("", [0,4,7]), ("m", [0,3,7]), ("7", [0,4,7,10]), ("maj7", [0,4,7,11]), ("m7", [0,3,7,10]), ("sus4", [0,5,7])]:
        vec = np.zeros(12, dtype=float)
        for interval in intervals:
            vec[(root + interval) % 12] = 1.0
        CHORD_TEMPLATES[f"{NOTE_NAMES[root]}{suffix}"] = vec / np.linalg.norm(vec)

def estimate_chords(y: np.ndarray, sr: int) -> list[dict[str, Any]]:
    # Chroma-template baseline. Works best on clear, tonal audio; not a source-separated guitar transcription.
    hop = 512
    chroma = librosa.feature.chroma_stft(y=y, sr=sr, hop_length=hop, n_fft=4096)
    seconds_per_frame = hop / sr
    window_frames = max(1, int(1.8 / seconds_per_frame))
    result = []
    for start in range(0, chroma.shape[1], window_frames):
        end = min(chroma.shape[1], start + window_frames)
        if end - start < max(2, int(0.25 / seconds_per_frame)):
            continue
        profile = np.mean(chroma[:, start:end], axis=1)
        norm = np.linalg.norm(profile)
        if norm:
            profile = profile / norm
        scores = {name: float(np.dot(profile, template)) for name, template in CHORD_TEMPLATES.items()}
        ordered = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        best_name, best_score = ordered[0]
        second_score = ordered[1][1] if len(ordered) > 1 else 0.0
        start_s = round(start * seconds_per_frame, 2)
        end_s = round(end * seconds_per_frame, 2)
        # Merge consecutive same chord estimates.
        confidence = max(0.0, min(1.0, (best_score - second_score) / max(best_score, 1e-6) * 2.5))
        if result and result[-1]["chord"] == best_name:
            result[-1]["end"] = end_s
            result[-1]["confidence"] = round((result[-1]["confidence"] + confidence) / 2, 2)
        else:
            result.append({"start": start_s, "end": end_s, "chord": best_name, "confidence": round(confidence, 2)})
    return result

def note_to_fret(midi: int, max_fret: int = 15):
    # Standard tuning, low to high: E2 A2 D3 G3 B3 E4
    open_midi = [40, 45, 50, 55, 59, 64]
    candidates = []
    for string_index, open_note in enumerate(open_midi):
        fret = midi - open_note
        if 0 <= fret <= max_fret:
            candidates.append({"string": 6 - string_index, "fret": int(fret), "midi": int(midi)})
    if not candidates:
        return None
    return min(candidates, key=lambda x: x["fret"])

def estimate_tabs(y: np.ndarray, sr: int) -> dict[str, Any]:
    # Optional Basic Pitch is best on isolated single-instrument stems; do not pretend a full mix is reliable.
    try:
        from basic_pitch.inference import predict
        with tempfile.TemporaryDirectory() as td:
            audio_path = os.path.join(td, "audio.wav")
            import soundfile as sf
            sf.write(audio_path, y, sr)
            model_output, midi_data, note_events = predict(audio_path)
            notes = []
            for event in note_events:
                # Basic Pitch note_events format: (start, end, pitch_midi, amplitude, pitch_bend)
                start, end, midi, amp = event[:4]
                fret = note_to_fret(int(round(midi)))
                if fret:
                    notes.append({"start": round(float(start), 2), "end": round(float(end), 2),
                                  "note": NOTE_NAMES[int(round(midi)) % 12], "octave": int(round(midi)) // 12 - 1,
                                  "string": fret["string"], "fret": fret["fret"], "confidence": round(float(amp), 2)})
            return {"available": True, "method": "Spotify Basic Pitch + standard-tuning fretboard mapping",
                    "warning": "Tab is a candidate transcription. Accuracy is much better on an isolated guitar stem than a full song mix.",
                    "notes": notes[:1500]}
    except Exception as exc:
        return {"available": False, "method": "Basic Pitch optional dependency not available",
                "warning": "Install the optional Basic Pitch extra on a compatible server to enable note/tab candidates.",
                "notes": [], "detail": str(exc)[:240]}

def transcribe_lyrics(audio_path: str) -> dict[str, Any]:
    model_name = os.getenv("WHISPER_MODEL", "small")
    try:
        from faster_whisper import WhisperModel
        # On hosted CPU, int8 reduces memory. For best accuracy use a GPU deployment if available.
        model = WhisperModel(model_name, device=os.getenv("WHISPER_DEVICE", "cpu"),
                             compute_type=os.getenv("WHISPER_COMPUTE_TYPE", "int8"))
        segments, info = model.transcribe(audio_path, vad_filter=True, word_timestamps=True)
        rows = []
        for seg in segments:
            words = []
            if seg.words:
                for word in seg.words:
                    words.append({"text": word.word, "start": round(word.start, 2), "end": round(word.end, 2)})
            rows.append({"start": round(seg.start, 2), "end": round(seg.end, 2),
                         "text": seg.text.strip(), "words": words})
        return {"available": True, "language": info.language, "segments": rows}
    except Exception as exc:
        return {"available": False, "language": None, "segments": [],
                "warning": "Lyrics model unavailable. Install faster-whisper; singing recognition may need manual correction.",
                "detail": str(exc)[:240]}

@app.get("/", response_class=HTMLResponse)
def home():
    return (ROOT / "static" / "index.html").read_text(encoding="utf-8")

@app.get("/health")
def health():
    return {"ok": True, "app": "SenarAI", "version": "0.1.0"}

@app.post("/analyze")
async def analyze(file: UploadFile = File(...)):
    allowed = {".mp3", ".wav", ".m4a", ".ogg", ".flac", ".webm"}
    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in allowed:
        raise HTTPException(400, "Format tidak didukung. Gunakan MP3, WAV, M4A, OGG, FLAC, atau WEBM.")
    data = await file.read()
    if not data:
        raise HTTPException(400, "File audio kosong.")
    if len(data) > MAX_BYTES:
        raise HTTPException(413, f"File terlalu besar. Batas {MAX_BYTES // (1024*1024)} MB.")
    with tempfile.TemporaryDirectory() as td:
        source = Path(td) / ("source" + suffix)
        source.write_bytes(data)
        try:
            y, sr = librosa.load(str(source), sr=22050, mono=True, duration=300)
        except Exception as exc:
            raise HTTPException(422, f"Audio gagal dibaca: {str(exc)[:180]}")
        if len(y) < sr:
            raise HTTPException(422, "Audio terlalu pendek; unggah minimal 1 detik.")
        chords = estimate_chords(y, sr)
        lyrics = transcribe_lyrics(str(source))
        tabs = estimate_tabs(y, sr)
        tempo, _ = librosa.beat.beat_track(y=y, sr=sr)
        return {
            "filename": file.filename, "duration_seconds": round(len(y)/sr, 2),
            "sample_rate": sr, "tempo_bpm_estimate": round(float(np.asarray(tempo).reshape(-1)[0]), 1),
            "chords": chords, "lyrics": lyrics, "tabs": tabs,
            "notes": [
                "Chord saat ini adalah estimasi berbasis chroma, bukan jaminan chord asli.",
                "Tab dari lagu full-mix bisa mencampur nada gitar, vokal, bass, dan instrumen lain.",
                "Capo recommendation akan ditambahkan setelah kandidat chord/tab dapat dibandingkan dengan tuning dan bentuk chord yang playable."
            ]
        }
